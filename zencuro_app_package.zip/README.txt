Zencuro Android Wrapper — Ready-to-Build Project
-----------------------------------------------
What this is
- An Android Studio WebView project that loads the public Zencuro site: https://zencuro.onrender.com
- Includes offline fallback (assets/www/index.html) and a service worker for basic offline caching.
- Includes a placeholder FirebaseMessagingService to enable push notifications (requires google-services.json).
- Branding: app name 'Zencuro' and simple logo/styled fallback page.

How to build the APK (on your machine)
1. Install Android Studio and required SDKs.
2. Open this folder in Android Studio: ZencuroApp
3. Let Gradle sync. You may need to update plugin versions as prompted.
4. If you want FCM (push notifications):
   a) Create a Firebase project at https://console.firebase.google.com/
   b) Add an Android app package name: com.zencuro.app
   c) Download google-services.json and place it in ZencuroApp/app/
   d) Add google-services plugin in build.gradle as prompted by Firebase docs.
5. Build -> Build Bundle(s) / APK(s) -> Build APK(s).
6. Install the generated APK on your phone.

Notes about push notifications
- Server-side: to send push notifications you must integrate Firebase Admin SDK or use FCM HTTP API.
- This project includes a client-side FirebaseMessagingService that shows notifications. To fully enable it, add google-services.json and the Firebase SDK configuration.

Offline behavior
- When the app cannot reach the remote site, it will show the local offline fallback (assets/www/index.html) with basic info and cached content.

If you want, I can:
- Build the unsigned APK for you (requires Android SDK access on my side — may not be possible in this environment).
- Integrate FCM fully and add an admin UI to send notifications.
- Wrap this as a Capacitor app and produce CI scripts to generate APKs automatically.
